# Responsive Blog Card Slider 

A Pen created on CodePen.io. Original URL: [https://codepen.io/JavaScriptJunkie/pen/WgRBxw](https://codepen.io/JavaScriptJunkie/pen/WgRBxw).

Responsive slider for featured blog posts. Also can use for other things like card slider. Built with Swiper slider. 